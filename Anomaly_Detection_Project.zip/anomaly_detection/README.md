# Anomaly Detection using Isolation Forest

A beginner-friendly Python machine-learning project that identifies unusual sensor readings using the Isolation Forest algorithm.

## Files
- `anomaly_detection.py` — project source code
- `sensor_anomaly_dataset.csv` — synthetic example sensor dataset
- `anomaly_detection_predictions.csv` — model predictions
- `anomaly_scatter.png` — readings visualization
- `confusion_matrix.png` — evaluation visualization
- `anomaly_flowchart.png` — project workflow
- `run_output.txt` — example run output

## Requirements
Python 3.9 or newer is recommended. Install dependencies from `requirements.txt` in the project root:

```bash
python -m pip install -r requirements.txt
```

## Run
From the extracted project folder:

```bash
python anomaly_detection.py
```

## Flowchart
![Anomaly Detection Flowchart](anomaly_flowchart.png)

**Note:** The included sensor dataset is synthetic and intended for learning/demo purposes. Do not describe its results as company or production results.
